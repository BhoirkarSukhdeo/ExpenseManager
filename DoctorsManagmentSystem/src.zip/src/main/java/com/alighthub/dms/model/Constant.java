package com.alighthub.dms.model;



/*
 * 
 * @author Ravindra Sonawane
 * @page Constant
 * @time 08/09/2019 - 9.05 PM
 * @purpose We have created this POJO to store all constant values 
 *  so we can use this values any where in the program without creating object.
 * 
 *
 */
public class Constant {
	public static final String LOGIN_ID="1001";
}
